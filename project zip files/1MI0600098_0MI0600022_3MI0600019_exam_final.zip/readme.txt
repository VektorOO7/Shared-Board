


Version:
    final (hopefully)

Files:
    './Shared Board' - Shortcut for the web app
    './app/' - Folder with all the code
    './Documentation.pdf' - Documentation for the project
    '.db_create_script.sql/' - SQL Script for creating the DB
    '.db_create_script (testing).sql/' - SQL Script for creating the DB + testing data
    './test_images/' - A directory with images for testing purposes

Required Versions:
    XAMPP Control Panel v3.3.0
    Apache 2.4.58
    MariaDB 10.4.32
    PHP version 8.2.12

Used Ports:
    Apache Port = 8443
    MySQL Port = 3307